"""
Casos de prueba del sistema.  Ejecutar con:  python manage.py test detector
"""
import numpy as np
from django.test import TestCase
from django.urls import reverse

from .models import RegistroConteo, SesionMonitoreo
from .services.contador import ContadorPersonas, RastreadorCentroides


class RastreadorTests(TestCase):
    def test_mantiene_el_mismo_id_si_la_persona_se_mueve_poco(self):
        r = RastreadorCentroides()
        r.actualizar([(100, 100, 40, 40)])
        r.actualizar([(110, 105, 40, 40)])
        self.assertEqual(list(r.objetos.keys()), [0])

    def test_asigna_ids_distintos_a_personas_separadas(self):
        r = RastreadorCentroides()
        r.actualizar([(10, 10, 40, 40), (400, 300, 40, 40)])
        self.assertEqual(len(r.objetos), 2)

    def test_elimina_personas_que_desaparecen(self):
        r = RastreadorCentroides(max_desaparecido=2)
        r.actualizar([(10, 10, 40, 40)])
        for _ in range(3):
            r.actualizar([])
        self.assertEqual(len(r.objetos), 0)


class ConteoLineaTests(TestCase):
    def _simular(self, ys):
        contador = ContadorPersonas(modo="rostro", aforo=10)
        for y in ys:
            caja = (300, y, 40, 40)
            objetos = contador.rastreador.actualizar([caja])
            contador._contar_cruces(objetos, 640, 480)
        return contador

    def test_cuenta_una_entrada_al_cruzar_la_linea_hacia_abajo(self):
        c = self._simular([150, 180, 210, 240, 270])  # línea en y = 240
        self.assertEqual((c.entradas, c.salidas), (1, 0))

    def test_cuenta_una_salida_al_cruzar_la_linea_hacia_arriba(self):
        c = self._simular([300, 270, 240, 210, 180])
        self.assertEqual((c.entradas, c.salidas), (0, 1))

    def test_procesa_un_fotograma_vacio_sin_detectar_personas(self):
        contador = ContadorPersonas(modo="cuerpo", aforo=5)
        frame = np.zeros((480, 640, 3), dtype=np.uint8)
        anotado, stats = contador.procesar(frame)
        self.assertEqual(stats["personas"], 0)
        self.assertEqual(anotado.shape, (480, 640, 3))
        self.assertFalse(stats["aforo_excedido"])


class VistasTests(TestCase):
    def test_panel_carga(self):
        r = self.client.get(reverse("detector:panel"))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "Iniciar monitoreo")

    def test_api_estado_responde_json(self):
        r = self.client.get(reverse("detector:api_estado"))
        self.assertEqual(r.status_code, 200)
        self.assertFalse(r.json()["activa"])

    def test_exportar_csv_de_una_sesion(self):
        s = SesionMonitoreo.objects.create(aforo_maximo=30)
        RegistroConteo.objects.create(sesion=s, personas=4, entradas=2, salidas=1)
        r = self.client.get(reverse("detector:exportar_csv", args=[s.id]))
        self.assertEqual(r.status_code, 200)
        self.assertIn("Personas", r.content.decode("utf-8"))
