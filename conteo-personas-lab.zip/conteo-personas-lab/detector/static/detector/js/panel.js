// Actualiza los indicadores del panel consultando /api/estado/ cada segundo.
(function () {
  const cfg = window.CONFIG;
  const $ = (id) => document.getElementById(id);
  const MAX_PUNTOS = 120;

  const grafica = new Chart($("grafica-vivo"), {
    type: "line",
    data: {
      labels: [],
      datasets: [{
        label: "Personas",
        data: [],
        borderColor: "#2563eb",
        backgroundColor: "rgba(37, 99, 235, 0.12)",
        fill: true,
        tension: 0.3,
        pointRadius: 0,
        borderWidth: 2,
      }],
    },
    options: {
      animation: false,
      plugins: { legend: { display: false } },
      scales: {
        y: { beginAtZero: true, ticks: { precision: 0 } },
        x: { ticks: { maxTicksLimit: 8 } },
      },
    },
  });

  function pintar(e) {
    if (e.personas === undefined) return;
    $("personas").textContent = e.personas;
    $("entradas").textContent = e.entradas;
    $("salidas").textContent = e.salidas;
    $("aforo").textContent = e.aforo;
    $("porcentaje").textContent = e.porcentaje_aforo;
    if ($("fps")) $("fps").textContent = e.fps;

    const barra = $("barra-aforo");
    barra.style.width = Math.min(e.porcentaje_aforo, 100) + "%";
    barra.className = "progress-bar " + (e.aforo_excedido ? "bg-danger" : e.porcentaje_aforo > 80 ? "bg-warning" : "bg-success");
    $("alerta-aforo").classList.toggle("d-none", !e.aforo_excedido);
    $("kpi-personas").classList.toggle("excedido", e.aforo_excedido);

    const hora = new Date().toLocaleTimeString("es-EC", { hour12: false });
    grafica.data.labels.push(hora);
    grafica.data.datasets[0].data.push(e.personas);
    if (grafica.data.labels.length > MAX_PUNTOS) {
      grafica.data.labels.shift();
      grafica.data.datasets[0].data.shift();
    }
    grafica.update();
  }

  async function consultar() {
    try {
      const r = await fetch(cfg.urlEstado, { cache: "no-store" });
      const e = await r.json();
      if (cfg.activa && !e.activa) {
        // La cámara se detuvo (error o fin de señal): recargar para mostrar el estado real.
        if (e.error) alert(e.error);
        window.location.reload();
        return;
      }
      pintar(e);
    } catch (err) {
      console.warn("No se pudo consultar el estado", err);
    }
  }

  const btn = $("btn-reiniciar");
  if (btn) {
    btn.addEventListener("click", async () => {
      await fetch(btn.dataset.url, { method: "POST", headers: { "X-CSRFToken": cfg.csrf } });
      grafica.data.labels = [];
      grafica.data.datasets[0].data = [];
      grafica.update();
    });
  }

  if (cfg.activa) {
    consultar();
    setInterval(consultar, 1000);
  }
})();
