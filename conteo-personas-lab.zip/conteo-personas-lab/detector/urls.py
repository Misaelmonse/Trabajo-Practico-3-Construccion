from django.urls import path

from . import views

app_name = "detector"

urlpatterns = [
    path("", views.panel, name="panel"),
    path("monitoreo/iniciar/", views.iniciar, name="iniciar"),
    path("monitoreo/detener/", views.detener, name="detener"),
    path("monitoreo/reiniciar/", views.reiniciar, name="reiniciar"),
    path("video/", views.video, name="video"),
    path("api/estado/", views.api_estado, name="api_estado"),
    path("historial/", views.historial, name="historial"),
    path("historial/<int:pk>/", views.detalle_sesion, name="detalle"),
    path("historial/<int:pk>/registros/", views.api_registros, name="api_registros"),
    path("historial/<int:pk>/csv/", views.exportar_csv, name="exportar_csv"),
    path("historial/<int:pk>/eliminar/", views.eliminar_sesion, name="eliminar"),
]
