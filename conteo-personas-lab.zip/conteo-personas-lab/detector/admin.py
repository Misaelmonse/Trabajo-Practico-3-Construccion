from django.contrib import admin

from .models import AlertaAforo, RegistroConteo, SesionMonitoreo


class RegistroInline(admin.TabularInline):
    model = RegistroConteo
    extra = 0
    readonly_fields = ("fecha", "personas", "entradas", "salidas", "fps")
    can_delete = False


@admin.register(SesionMonitoreo)
class SesionAdmin(admin.ModelAdmin):
    list_display = ("id", "nombre", "modo", "inicio", "fin", "max_personas", "total_entradas", "total_salidas")
    list_filter = ("modo",)
    inlines = [RegistroInline]


@admin.register(RegistroConteo)
class RegistroAdmin(admin.ModelAdmin):
    list_display = ("sesion", "fecha", "personas", "entradas", "salidas", "fps")
    list_filter = ("sesion",)


@admin.register(AlertaAforo)
class AlertaAdmin(admin.ModelAdmin):
    list_display = ("sesion", "fecha", "personas", "aforo")
