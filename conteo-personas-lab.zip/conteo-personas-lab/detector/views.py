import csv
import time

from django.conf import settings
from django.contrib import messages
from django.db.models import Max, Sum
from django.http import HttpResponse, JsonResponse, StreamingHttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from .forms import ConfiguracionForm
from .models import AlertaAforo, RegistroConteo, SesionMonitoreo
from .services.camara import camara


def _cerrar_sesiones_huerfanas():
    """Si el servidor se reinició con una sesión abierta, se cierra al cargar la página."""
    if not camara.activa:
        SesionMonitoreo.objects.filter(fin__isnull=True).exclude(pk=camara.sesion_id).update(fin=timezone.now())


def panel(request):
    _cerrar_sesiones_huerfanas()
    form = ConfiguracionForm(initial={"aforo_maximo": settings.AFORO_POR_DEFECTO})
    sesion_actual = SesionMonitoreo.objects.filter(pk=camara.sesion_id).first() if camara.activa else None
    contexto = {
        "form": form,
        "sesion_actual": sesion_actual,
        "camara_activa": camara.activa,
        "alertas": AlertaAforo.objects.select_related("sesion")[:5],
        "totales": {
            "sesiones": SesionMonitoreo.objects.count(),
            "registros": RegistroConteo.objects.count(),
            "max_historico": SesionMonitoreo.objects.aggregate(m=Max("max_personas"))["m"] or 0,
            "entradas": SesionMonitoreo.objects.aggregate(s=Sum("total_entradas"))["s"] or 0,
        },
    }
    return render(request, "detector/panel.html", contexto)


@require_POST
def iniciar(request):
    form = ConfiguracionForm(request.POST)
    if not form.is_valid():
        messages.error(request, "Revisa la configuración: " + form.errors.as_text())
        return redirect("detector:panel")
    sesion = form.save()
    camara.iniciar(sesion, fuente=form.cleaned_data.get("fuente"))
    messages.success(request, f"Monitoreo iniciado en modo «{sesion.get_modo_display()}».")
    return redirect("detector:panel")


@require_POST
def detener(request):
    camara.detener()
    messages.info(request, "Monitoreo detenido. La sesión quedó guardada en el historial.")
    return redirect("detector:panel")


@require_POST
def reiniciar(request):
    camara.reiniciar_contadores()
    return JsonResponse({"ok": True})


def _generador_mjpeg():
    """Envía fotogramas JPEG como multipart/x-mixed-replace (MJPEG) al navegador."""
    ultimo = None
    while True:
        jpeg = camara.obtener_jpeg()
        if jpeg is not ultimo:
            ultimo = jpeg
            yield b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + jpeg + b"\r\n"
        if not camara.activa:
            # Se envía la imagen de "cámara detenida" y se cierra el stream.
            yield b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + camara.obtener_jpeg() + b"\r\n"
            break
        time.sleep(0.03)


def video(request):
    respuesta = StreamingHttpResponse(_generador_mjpeg(),
                                      content_type="multipart/x-mixed-replace; boundary=frame")
    respuesta["Cache-Control"] = "no-cache"
    return respuesta


def api_estado(request):
    return JsonResponse(camara.estado())


def historial(request):
    _cerrar_sesiones_huerfanas()
    sesiones = SesionMonitoreo.objects.all()[:50]
    return render(request, "detector/historial.html", {"sesiones": sesiones})


def detalle_sesion(request, pk):
    sesion = get_object_or_404(SesionMonitoreo, pk=pk)
    return render(request, "detector/detalle.html", {
        "sesion": sesion,
        "registros": sesion.registros.all(),
        "alertas": sesion.alertas.all(),
    })


def api_registros(request, pk):
    sesion = get_object_or_404(SesionMonitoreo, pk=pk)
    datos = [
        {
            "hora": timezone.localtime(r.fecha).strftime("%H:%M:%S"),
            "personas": r.personas,
            "entradas": r.entradas,
            "salidas": r.salidas,
        }
        for r in sesion.registros.all()
    ]
    return JsonResponse({"sesion": sesion.id, "aforo": sesion.aforo_maximo, "registros": datos})


def exportar_csv(request, pk):
    sesion = get_object_or_404(SesionMonitoreo, pk=pk)
    respuesta = HttpResponse(content_type="text/csv; charset=utf-8")
    respuesta["Content-Disposition"] = f'attachment; filename="sesion_{sesion.id}.csv"'
    respuesta.write("﻿")  # BOM para que Excel muestre bien las tildes
    escritor = csv.writer(respuesta)
    escritor.writerow(["Fecha", "Hora", "Personas", "Entradas", "Salidas", "FPS"])
    for r in sesion.registros.all():
        local = timezone.localtime(r.fecha)
        escritor.writerow([local.strftime("%d/%m/%Y"), local.strftime("%H:%M:%S"),
                           r.personas, r.entradas, r.salidas, r.fps])
    return respuesta


@require_POST
def eliminar_sesion(request, pk):
    sesion = get_object_or_404(SesionMonitoreo, pk=pk)
    if camara.activa and camara.sesion_id == sesion.id:
        messages.error(request, "No puedes eliminar la sesión que está en curso.")
    else:
        sesion.delete()
        messages.success(request, "Sesión eliminada.")
    return redirect("detector:historial")
