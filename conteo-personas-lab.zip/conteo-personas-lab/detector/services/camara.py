"""
Captura de video en tiempo real.

Un hilo en segundo plano lee la cámara con OpenCV, procesa cada fotograma con el
ContadorPersonas y guarda el último resultado (JPEG + estadísticas). Las vistas de
Django solo leen ese resultado, así varios navegadores pueden ver el mismo stream.
Cada REGISTRO_INTERVALO_SEGUNDOS se guarda una muestra del conteo en PostgreSQL.
"""
import logging
import threading
import time

import cv2
import numpy as np
from django.conf import settings
from django.db import close_old_connections
from django.utils import timezone

from .contador import ContadorPersonas

logger = logging.getLogger(__name__)


def _fuente_video(valor):
    valor = str(valor).strip()
    return int(valor) if valor.isdigit() else valor


def _imagen_mensaje(texto, ancho=640, alto=360):
    img = np.full((alto, ancho, 3), 30, dtype=np.uint8)
    for i, linea in enumerate(texto.split("\n")):
        cv2.putText(img, linea, (30, alto // 2 - 10 + i * 32), cv2.FONT_HERSHEY_SIMPLEX,
                    0.7, (220, 220, 220), 2, cv2.LINE_AA)
    _, buffer = cv2.imencode(".jpg", img)
    return buffer.tobytes()


IMAGEN_DETENIDA = None


def imagen_detenida():
    global IMAGEN_DETENIDA
    if IMAGEN_DETENIDA is None:
        IMAGEN_DETENIDA = _imagen_mensaje("Camara detenida\nPresiona 'Iniciar monitoreo'")
    return IMAGEN_DETENIDA


class CamaraMonitoreo:
    def __init__(self):
        self._lock = threading.Lock()
        self._hilo = None
        self._activo = threading.Event()
        self.contador = None
        self.sesion_id = None
        self.ultimo_jpeg = imagen_detenida()
        self.ultimas_stats = {}
        self.fps = 0.0
        self.error = None
        self._ultimo_registro = 0.0
        self._alerta_activa = False

    # ------------------------------------------------------------------ control
    @property
    def activa(self):
        return self._activo.is_set()

    def iniciar(self, sesion, fuente=None):
        if self.activa:
            self.detener()
        self.contador = ContadorPersonas(
            modo=sesion.modo, aforo=sesion.aforo_maximo,
            posicion_linea=settings.LINEA_POSICION, orientacion=settings.LINEA_ORIENTACION,
            escala_hog=settings.HOG_ESCALA, detectar_cada=settings.DETECTAR_CADA_N_FRAMES,
        )
        self.sesion_id = sesion.id
        self.error = None
        self.fps = 0.0
        self.ultimas_stats = self.contador.estadisticas()
        self._alerta_activa = False
        self._ultimo_registro = time.time()
        self._activo.set()
        fuente = _fuente_video(fuente if fuente not in (None, "") else settings.VIDEO_SOURCE)
        self._hilo = threading.Thread(target=self._bucle, args=(fuente,), daemon=True)
        self._hilo.start()

    def detener(self):
        self._activo.clear()
        if self._hilo and self._hilo.is_alive() and self._hilo is not threading.current_thread():
            self._hilo.join(timeout=3)
        self._hilo = None
        self._finalizar_sesion()
        with self._lock:
            self.ultimo_jpeg = imagen_detenida()

    def reiniciar_contadores(self):
        if self.contador:
            self.contador.reiniciar()

    # ------------------------------------------------------------------ lectura
    def obtener_jpeg(self):
        with self._lock:
            return self.ultimo_jpeg

    def estado(self):
        with self._lock:
            stats = dict(self.ultimas_stats)
        stats.update({
            "activa": self.activa,
            "fps": round(self.fps, 1),
            "sesion_id": self.sesion_id,
            "error": self.error,
        })
        return stats

    # ------------------------------------------------------------------ hilo
    def _bucle(self, fuente):
        captura = cv2.VideoCapture(fuente)
        if not captura.isOpened():
            self.error = f"No se pudo abrir la fuente de video: {fuente}"
            logger.error(self.error)
            with self._lock:
                self.ultimo_jpeg = _imagen_mensaje("No se pudo abrir la camara\nRevisa VIDEO_SOURCE en .env")
            self._activo.clear()
            self._finalizar_sesion()
            return

        es_archivo = isinstance(fuente, str)
        pausa_archivo = 1.0 / (captura.get(cv2.CAP_PROP_FPS) or 25) if es_archivo else 0
        t_anterior = time.time()
        try:
            while self._activo.is_set():
                ok, frame = captura.read()
                if not ok:
                    if es_archivo:  # un video de prueba se repite en bucle
                        captura.set(cv2.CAP_PROP_POS_FRAMES, 0)
                        continue
                    self.error = "Se perdió la señal de la cámara"
                    break

                anotado, stats = self.contador.procesar(frame)
                ok_jpg, buffer = cv2.imencode(".jpg", anotado, [cv2.IMWRITE_JPEG_QUALITY, 80])

                ahora = time.time()
                instantaneo = 1.0 / max(ahora - t_anterior, 1e-6)
                self.fps = instantaneo if self.fps == 0 else 0.9 * self.fps + 0.1 * instantaneo
                t_anterior = ahora

                with self._lock:
                    if ok_jpg:
                        self.ultimo_jpeg = buffer.tobytes()
                    self.ultimas_stats = stats

                self._persistir(stats, ahora)
                if pausa_archivo:
                    time.sleep(pausa_archivo)
        finally:
            captura.release()
            self._activo.clear()

    # ------------------------------------------------------------------ BD
    def _persistir(self, stats, ahora):
        from ..models import AlertaAforo, RegistroConteo, SesionMonitoreo

        try:
            close_old_connections()
            if stats["aforo_excedido"] and not self._alerta_activa:
                AlertaAforo.objects.create(sesion_id=self.sesion_id, personas=stats["personas"],
                                           aforo=stats["aforo"])
                self._alerta_activa = True
            elif not stats["aforo_excedido"]:
                self._alerta_activa = False

            if ahora - self._ultimo_registro >= settings.REGISTRO_INTERVALO_SEGUNDOS:
                self._ultimo_registro = ahora
                RegistroConteo.objects.create(
                    sesion_id=self.sesion_id, personas=stats["personas"],
                    entradas=stats["entradas"], salidas=stats["salidas"], fps=round(self.fps, 1),
                )
                sesion = SesionMonitoreo.objects.get(pk=self.sesion_id)
                sesion.total_entradas = stats["entradas"]
                sesion.total_salidas = stats["salidas"]
                sesion.max_personas = max(sesion.max_personas, stats["personas"])
                sesion.save(update_fields=["total_entradas", "total_salidas", "max_personas"])
        except Exception:  # la detección no debe caerse por un fallo puntual de la BD
            logger.exception("Error al guardar el registro de conteo")

    def _finalizar_sesion(self):
        from ..models import SesionMonitoreo

        if not self.sesion_id:
            return
        try:
            close_old_connections()
            sesion = SesionMonitoreo.objects.filter(pk=self.sesion_id, fin__isnull=True).first()
            if sesion:
                stats = self.ultimas_stats or {}
                sesion.fin = timezone.now()
                sesion.total_entradas = stats.get("entradas", sesion.total_entradas)
                sesion.total_salidas = stats.get("salidas", sesion.total_salidas)
                sesion.max_personas = max(sesion.max_personas, stats.get("personas", 0))
                sesion.save()
        except Exception:
            logger.exception("Error al cerrar la sesión")


# Instancia única compartida por todas las vistas.
camara = CamaraMonitoreo()
