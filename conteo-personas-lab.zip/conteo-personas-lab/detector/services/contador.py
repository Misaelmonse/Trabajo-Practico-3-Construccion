"""
Módulo de procesamiento con OpenCV para el conteo de personas.

Flujo por cada fotograma:
    1. Detección  -> se localizan personas (cuerpo con HOG+SVM o rostros con Haar Cascade).
    2. Seguimiento -> un rastreador de centroides asigna un ID a cada persona entre fotogramas.
    3. Conteo      -> se cuentan las personas visibles y los cruces de una línea virtual
                      (entradas / salidas del laboratorio).
    4. Anotación   -> se dibujan cajas, IDs, línea y un panel con los resultados en el video.
"""
from collections import OrderedDict, deque

import cv2
import numpy as np


class DetectorPersonas:
    """Envuelve los dos detectores clásicos de OpenCV."""

    def __init__(self, modo="rostro", escala_hog=1.5):
        self.modo = modo
        # HOG usa una ventana de 64x128 px: ampliar la imagen permite detectar
        # personas lejanas (más pequeñas) a cambio de más tiempo de proceso.
        self.escala_hog = escala_hog
        # Detector de cuerpo completo: HOG + SVM preentrenado (incluido en OpenCV).
        self.hog = cv2.HOGDescriptor()
        self.hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
        # Detector de rostros: clasificadores en cascada de Haar (incluidos en opencv-python).
        self.cascada_frontal = cv2.CascadeClassifier(
            cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        )
        self.cascada_perfil = cv2.CascadeClassifier(
            cv2.data.haarcascades + "haarcascade_profileface.xml"
        )
        if self.cascada_frontal.empty():
            raise RuntimeError("No se pudo cargar haarcascade_frontalface_default.xml")

    def detectar(self, frame):
        """Devuelve una lista de cajas (x, y, w, h) en coordenadas del fotograma."""
        if self.modo == "cuerpo":
            return self._detectar_cuerpos(frame)
        return self._detectar_rostros(frame)

    def _detectar_cuerpos(self, frame):
        esc = self.escala_hog
        imagen = cv2.resize(frame, None, fx=esc, fy=esc) if esc != 1 else frame
        cajas, pesos = self.hog.detectMultiScale(
            imagen, winStride=(8, 8), padding=(8, 8), scale=1.05
        )
        if len(cajas) == 0:
            return []
        pesos = np.array(pesos).flatten().tolist()
        cajas = [tuple(int(v / esc) for v in c) for c in cajas]
        return _supresion_no_maximos(cajas, pesos, umbral_score=0.4)

    def _detectar_rostros(self, frame):
        gris = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gris = cv2.equalizeHist(gris)
        frontales = self.cascada_frontal.detectMultiScale(
            gris, scaleFactor=1.1, minNeighbors=6, minSize=(30, 30)
        )
        cajas = [tuple(int(v) for v in c) for c in frontales]
        # Rostros de perfil (ambos lados, volteando la imagen) para no perder gente girada.
        if not self.cascada_perfil.empty():
            ancho = gris.shape[1]
            for c in self.cascada_perfil.detectMultiScale(gris, 1.1, 6, minSize=(30, 30)):
                cajas.append(tuple(int(v) for v in c))
            volteado = cv2.flip(gris, 1)
            for x, y, w, h in self.cascada_perfil.detectMultiScale(volteado, 1.1, 6, minSize=(30, 30)):
                cajas.append((int(ancho - x - w), int(y), int(w), int(h)))
        if not cajas:
            return []
        return _supresion_no_maximos(cajas, [1.0] * len(cajas), umbral_score=0.0)


def _supresion_no_maximos(cajas, pesos, umbral_score=0.4, umbral_iou=0.35):
    """Elimina cajas duplicadas que se superponen sobre la misma persona."""
    indices = cv2.dnn.NMSBoxes(
        [list(c) for c in cajas], [float(p) for p in pesos], umbral_score, umbral_iou
    )
    if len(indices) == 0:
        return []
    return [cajas[i] for i in np.array(indices).flatten()]


class RastreadorCentroides:
    """
    Seguimiento sencillo por centroides: asocia cada detección con la persona
    más cercana del fotograma anterior para mantener el mismo ID.
    """

    def __init__(self, max_desaparecido=25, max_distancia=90):
        self.siguiente_id = 0
        self.objetos = OrderedDict()      # id -> centroide (x, y)
        self.cajas = OrderedDict()        # id -> caja (x, y, w, h)
        self.desaparecidos = OrderedDict()
        self.max_desaparecido = max_desaparecido
        self.max_distancia = max_distancia

    def _registrar(self, centroide, caja):
        self.objetos[self.siguiente_id] = centroide
        self.cajas[self.siguiente_id] = caja
        self.desaparecidos[self.siguiente_id] = 0
        self.siguiente_id += 1

    def _eliminar(self, oid):
        del self.objetos[oid]
        del self.cajas[oid]
        del self.desaparecidos[oid]

    def actualizar(self, cajas):
        if len(cajas) == 0:
            for oid in list(self.desaparecidos):
                self.desaparecidos[oid] += 1
                if self.desaparecidos[oid] > self.max_desaparecido:
                    self._eliminar(oid)
            return self.objetos

        nuevos = np.array([(x + w // 2, y + h // 2) for (x, y, w, h) in cajas])

        if not self.objetos:
            for c, caja in zip(nuevos, cajas):
                self._registrar(tuple(c), caja)
            return self.objetos

        ids = list(self.objetos.keys())
        actuales = np.array(list(self.objetos.values()))
        distancias = np.linalg.norm(actuales[:, None, :] - nuevos[None, :, :], axis=2)

        filas = distancias.min(axis=1).argsort()
        columnas = distancias.argmin(axis=1)[filas]
        usadas_f, usadas_c = set(), set()
        for f, c in zip(filas, columnas):
            if f in usadas_f or c in usadas_c or distancias[f, c] > self.max_distancia:
                continue
            oid = ids[f]
            self.objetos[oid] = tuple(nuevos[c])
            self.cajas[oid] = cajas[c]
            self.desaparecidos[oid] = 0
            usadas_f.add(f)
            usadas_c.add(c)

        for f in set(range(len(ids))) - usadas_f:
            oid = ids[f]
            self.desaparecidos[oid] += 1
            if self.desaparecidos[oid] > self.max_desaparecido:
                self._eliminar(oid)

        for c in set(range(len(nuevos))) - usadas_c:
            self._registrar(tuple(nuevos[c]), cajas[c])

        return self.objetos


class ContadorPersonas:
    """Combina detector + rastreador + línea virtual y produce el fotograma anotado."""

    ANCHO_PROCESO = 640

    MARGEN_LINEA = 12  # px de tolerancia alrededor de la línea para evitar dobles conteos

    def __init__(self, modo="rostro", aforo=200, posicion_linea=0.5, orientacion="horizontal",
                 escala_hog=1.5, detectar_cada=2):
        self.detector = DetectorPersonas(modo, escala_hog=escala_hog)
        self.detectar_cada = max(1, int(detectar_cada))
        self._n_frame = 0
        self._ultimas_cajas = []
        self.rastreador = RastreadorCentroides()
        self.aforo = aforo
        self.posicion_linea = posicion_linea
        self.orientacion = orientacion
        self.historial_conteo = deque(maxlen=8)  # suaviza el parpadeo del conteo
        self.lado_anterior = {}                  # id -> lado de la línea (-1 / 1)
        self.entradas = 0
        self.salidas = 0
        self.personas = 0

    @property
    def modo(self):
        return self.detector.modo

    def cambiar_modo(self, modo):
        self.detector.modo = modo
        self.reiniciar()

    def reiniciar(self):
        self.rastreador = RastreadorCentroides()
        self._ultimas_cajas = []
        self.historial_conteo.clear()
        self.lado_anterior.clear()
        self.entradas = self.salidas = self.personas = 0

    def procesar(self, frame):
        """Procesa un fotograma BGR y devuelve (fotograma_anotado, estadísticas)."""
        alto, ancho = frame.shape[:2]
        if ancho > self.ANCHO_PROCESO:
            escala = self.ANCHO_PROCESO / ancho
            frame = cv2.resize(frame, (self.ANCHO_PROCESO, int(alto * escala)))
            alto, ancho = frame.shape[:2]

        # La detección es la parte costosa: se ejecuta cada N fotogramas y en los
        # intermedios se reutiliza el último resultado para que el video fluya.
        if self._n_frame % self.detectar_cada == 0:
            cajas = self.detector.detectar(frame)
            self._ultimas_cajas = cajas
            objetos = self.rastreador.actualizar(cajas)
            # Conteo suavizado: mediana de las últimas detecciones para evitar saltos.
            self.historial_conteo.append(len(cajas))
            self.personas = int(np.median(self.historial_conteo))
            self._contar_cruces(objetos, ancho, alto)
        else:
            cajas = self._ultimas_cajas
            objetos = self.rastreador.objetos
        self._n_frame += 1

        self._dibujar(frame, cajas, objetos, ancho, alto)
        return frame, self.estadisticas()

    def _coordenada_linea(self, ancho, alto):
        return int((alto if self.orientacion == "horizontal" else ancho) * self.posicion_linea)

    def _contar_cruces(self, objetos, ancho, alto):
        linea = self._coordenada_linea(ancho, alto)
        eje = 1 if self.orientacion == "horizontal" else 0
        for oid, centroide in objetos.items():
            if self.rastreador.desaparecidos.get(oid, 0) > 0:
                continue
            distancia = centroide[eje] - linea
            if abs(distancia) < self.MARGEN_LINEA:
                continue  # dentro de la franja de tolerancia: aún no decide el lado
            lado = 1 if distancia > 0 else -1
            previo = self.lado_anterior.get(oid)
            if previo is not None and previo != lado:
                # Bajar/avanzar a la derecha = entra; lo contrario = sale.
                if lado == 1:
                    self.entradas += 1
                else:
                    self.salidas += 1
            self.lado_anterior[oid] = lado
        for oid in list(self.lado_anterior):
            if oid not in objetos:
                del self.lado_anterior[oid]

    def estadisticas(self):
        return {
            "personas": self.personas,
            "entradas": self.entradas,
            "salidas": self.salidas,
            "ocupacion_neta": max(self.entradas - self.salidas, 0),
            "aforo": self.aforo,
            "porcentaje_aforo": round(self.personas * 100 / self.aforo, 1) if self.aforo else 0,
            "aforo_excedido": self.personas > self.aforo,
            "modo": self.modo,
        }

    def _dibujar(self, frame, cajas, objetos, ancho, alto):
        excedido = self.personas > self.aforo
        color_caja = (0, 0, 255) if excedido else (80, 200, 60)

        for (x, y, w, h) in cajas:
            cv2.rectangle(frame, (x, y), (x + w, y + h), color_caja, 2)

        for oid, (cx, cy) in objetos.items():
            if self.rastreador.desaparecidos.get(oid, 0) > 0:
                continue
            cv2.circle(frame, (int(cx), int(cy)), 4, (0, 220, 255), -1)
            cv2.putText(frame, f"ID {oid}", (int(cx) - 18, int(cy) - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 220, 255), 1, cv2.LINE_AA)

        linea = self._coordenada_linea(ancho, alto)
        if self.orientacion == "horizontal":
            cv2.line(frame, (0, linea), (ancho, linea), (255, 180, 0), 2)
        else:
            cv2.line(frame, (linea, 0), (linea, alto), (255, 180, 0), 2)

        # Panel semitransparente con los resultados.
        panel = frame.copy()
        cv2.rectangle(panel, (8, 8), (230, 98), (20, 20, 20), -1)
        cv2.addWeighted(panel, 0.55, frame, 0.45, 0, frame)
        texto_color = (80, 80, 255) if excedido else (255, 255, 255)
        cv2.putText(frame, f"Personas: {self.personas}", (16, 34),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, texto_color, 2, cv2.LINE_AA)
        cv2.putText(frame, f"Entradas: {self.entradas}  Salidas: {self.salidas}", (16, 60),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.48, (255, 255, 255), 1, cv2.LINE_AA)
        cv2.putText(frame, f"Aforo: {self.personas}/{self.aforo}", (16, 84),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.48, texto_color, 1, cv2.LINE_AA)
        if excedido:
            cv2.putText(frame, "AFORO EXCEDIDO", (ancho - 210, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2, cv2.LINE_AA)
