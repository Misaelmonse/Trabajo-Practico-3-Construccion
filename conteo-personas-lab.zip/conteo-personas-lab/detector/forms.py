from django import forms

from .models import SesionMonitoreo


class ConfiguracionForm(forms.ModelForm):
    fuente = forms.CharField(
        required=False,
        label="Fuente de video",
        help_text="Vacío = valor de .env. Usa 0 para la cámara web, 1 para una USB, o la ruta de un video.",
        widget=forms.TextInput(attrs={"class": "form-control", "placeholder": "0"}),
    )

    class Meta:
        model = SesionMonitoreo
        fields = ["nombre", "modo", "aforo_maximo"]
        labels = {
            "nombre": "Nombre del ambiente",
            "modo": "Método de detección",
            "aforo_maximo": "Aforo máximo",
        }
        widgets = {
            "nombre": forms.TextInput(attrs={"class": "form-control"}),
            "modo": forms.Select(attrs={"class": "form-select"}),
            "aforo_maximo": forms.NumberInput(attrs={"class": "form-control", "min": 1}),
        }
