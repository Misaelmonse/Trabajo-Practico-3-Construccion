from django.db import models


class SesionMonitoreo(models.Model):
    """Una sesión de monitoreo: desde que se inicia la cámara hasta que se detiene."""

    MODO_CUERPO = "cuerpo"
    MODO_ROSTRO = "rostro"
    MODOS = [
        (MODO_CUERPO, "Cuerpo completo (HOG + SVM)"),
        (MODO_ROSTRO, "Rostros (Haar Cascade)"),
    ]

    nombre = models.CharField(max_length=120, default="Laboratorio P - Bloque P")
    modo = models.CharField(max_length=10, choices=MODOS, default=MODO_ROSTRO)
    aforo_maximo = models.PositiveIntegerField(default=200)
    inicio = models.DateTimeField(auto_now_add=True)
    fin = models.DateTimeField(null=True, blank=True)
    total_entradas = models.PositiveIntegerField(default=0)
    total_salidas = models.PositiveIntegerField(default=0)
    max_personas = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["-inicio"]
        verbose_name = "sesión de monitoreo"
        verbose_name_plural = "sesiones de monitoreo"

    def __str__(self):
        return f"{self.nombre} - {self.inicio:%d/%m/%Y %H:%M}"

    @property
    def activa(self):
        return self.fin is None

    @property
    def duracion(self):
        from django.utils import timezone

        fin = self.fin or timezone.now()
        segundos = int((fin - self.inicio).total_seconds())
        h, resto = divmod(segundos, 3600)
        m, s = divmod(resto, 60)
        return f"{h:02d}:{m:02d}:{s:02d}"

    @property
    def promedio_personas(self):
        valor = self.registros.aggregate(p=models.Avg("personas"))["p"]
        return round(valor or 0, 1)


class RegistroConteo(models.Model):
    """Muestra periódica del conteo, guardada cada N segundos durante una sesión."""

    sesion = models.ForeignKey(SesionMonitoreo, on_delete=models.CASCADE, related_name="registros")
    fecha = models.DateTimeField(auto_now_add=True, db_index=True)
    personas = models.PositiveIntegerField()
    entradas = models.PositiveIntegerField(default=0)
    salidas = models.PositiveIntegerField(default=0)
    fps = models.FloatField(default=0)

    class Meta:
        ordering = ["fecha"]
        verbose_name = "registro de conteo"
        verbose_name_plural = "registros de conteo"

    def __str__(self):
        return f"{self.fecha:%H:%M:%S} → {self.personas} personas"


class AlertaAforo(models.Model):
    """Se crea cuando el número de personas supera el aforo configurado."""

    sesion = models.ForeignKey(SesionMonitoreo, on_delete=models.CASCADE, related_name="alertas")
    fecha = models.DateTimeField(auto_now_add=True)
    personas = models.PositiveIntegerField()
    aforo = models.PositiveIntegerField()

    class Meta:
        ordering = ["-fecha"]
        verbose_name = "alerta de aforo"
        verbose_name_plural = "alertas de aforo"

    def __str__(self):
        return f"Aforo excedido: {self.personas}/{self.aforo} ({self.fecha:%d/%m %H:%M})"
