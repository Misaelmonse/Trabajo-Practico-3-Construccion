# Conteo de Personas en el Laboratorio

Aplicativo web en **Django** que captura video en tiempo real, lo procesa con **OpenCV** para detectar y contar a las personas presentes en el laboratorio, y muestra los resultados en una interfaz web interactiva. Las sesiones y el historial de conteo se guardan en **PostgreSQL**.

> Práctica de visión artificial — Universidad Estatal de Milagro (UNEMI).
> Enfoque elegido: **Conteo de personas en el laboratorio**.

## Funcionalidades

- **Video en tiempo real** desde la cámara web (o un archivo de video), transmitido al navegador como MJPEG.
- **Dos métodos de detección con OpenCV** (seleccionables desde la interfaz):
  - **Rostros (Haar Cascade):** frontal + perfil. Recomendado cuando la cámara apunta a las personas sentadas frente a las computadoras.
  - **Cuerpo completo (HOG + SVM):** detector de peatones de OpenCV. Recomendado cuando la cámara ve a las personas de pie o caminando (por ejemplo, desde la puerta).
- **Seguimiento por centroides:** cada persona recibe un ID que se mantiene entre fotogramas.
- **Conteo de entradas y salidas** mediante una línea virtual: cruzar hacia abajo cuenta como entrada y hacia arriba como salida.
- **Control de aforo:** barra de ocupación, aviso visual y registro de alertas cuando se supera la capacidad configurada.
- **Panel en vivo** con indicadores y gráfica de los últimos 2 minutos.
- **Historial** de sesiones guardado en PostgreSQL, con gráfica por sesión, tabla de registros y **exportación a CSV**.
- **Panel de administración** de Django para revisar los datos.

## Tecnologías

| Componente | Uso |
|---|---|
| Python 3.10+ | Lenguaje backend |
| Django 5 | Framework web |
| OpenCV (cv2) | Captura, detección (HOG, Haar) y anotación del video |
| NumPy | Cálculos del rastreador |
| PostgreSQL + psycopg 3 | Base de datos |
| Bootstrap 5 + Chart.js | Interfaz (incluidos en `static/`, funcionan sin internet) |

## Estructura del proyecto

```
conteo-personas-lab/
├── manage.py
├── requirements.txt
├── .env.example                 # plantilla de configuración
├── conteo_personas/             # configuración del proyecto Django
│   ├── settings.py
│   └── urls.py
└── detector/                    # aplicación principal
    ├── models.py                # SesionMonitoreo, RegistroConteo, AlertaAforo
    ├── views.py                 # panel, stream de video, API, historial, CSV
    ├── forms.py
    ├── urls.py
    ├── tests.py                 # casos de prueba
    ├── services/
    │   ├── contador.py          # detección, seguimiento y conteo con OpenCV
    │   └── camara.py            # hilo de captura y guardado en la BD
    ├── templates/detector/      # panel.html, historial.html, detalle.html
    └── static/detector/         # CSS, JS y librerías de la interfaz
```

## Instalación

### 1. Clonar el repositorio

```bash
git clone https://github.com/<usuario>/conteo-personas-lab.git
cd conteo-personas-lab
```

### 2. Crear y activar un entorno virtual (no se sube a GitHub)

```bash
python -m venv venv
# Windows
venv\Scripts\activate
# Linux / macOS
source venv/bin/activate
```

### 3. Instalar dependencias

```bash
pip install -r requirements.txt
```

### 4. Crear la base de datos en PostgreSQL

Desde **pgAdmin** o la consola `psql`:

```sql
CREATE DATABASE conteo_personas;
```

### 5. Configurar variables de entorno

Copia `.env.example` como `.env` y coloca tus credenciales de PostgreSQL:

```bash
# Windows
copy .env.example .env
# Linux / macOS
cp .env.example .env
```

```ini
DB_NAME=conteo_personas
DB_USER=postgres
DB_PASSWORD=tu_contraseña
DB_HOST=localhost
DB_PORT=5432
VIDEO_SOURCE=0
```

### 6. Aplicar migraciones y crear un administrador

```bash
python manage.py migrate
python manage.py createsuperuser   # opcional, para entrar a /admin
```

### 7. Ejecutar

```bash
python manage.py runserver
```

Abre **http://127.0.0.1:8000/** en el navegador.

## Uso

1. En **Monitoreo**, elige el método de detección y el aforo máximo, y presiona **Iniciar monitoreo**.
2. El video aparece con las personas enmarcadas, su ID y la línea de entrada/salida. A la derecha se actualizan el número de personas, las entradas, las salidas y el porcentaje de aforo.
3. **Reiniciar contadores** pone en cero las entradas y salidas sin cerrar la sesión.
4. **Detener monitoreo** apaga la cámara y cierra la sesión.
5. En **Historial** se ven todas las sesiones; **Ver** muestra la gráfica y los registros, y **CSV** descarga los datos.

## Configuración avanzada (`.env`)

| Variable | Descripción | Valor por defecto |
|---|---|---|
| `VIDEO_SOURCE` | `0` cámara integrada, `1` cámara USB, o ruta de un video | `0` |
| `REGISTRO_INTERVALO_SEGUNDOS` | Cada cuánto se guarda una muestra en la BD | `5` |
| `AFORO_POR_DEFECTO` | Aforo sugerido en el formulario | `200` |
| `LINEA_POSICION` | Posición de la línea de conteo (0 a 1) | `0.5` |
| `LINEA_ORIENTACION` | `horizontal` o `vertical` | `horizontal` |
| `HOG_ESCALA` | Ampliación para el detector de cuerpo; más alto detecta personas lejanas pero es más lento | `1.5` |
| `DETECTAR_CADA_N_FRAMES` | Detectar cada N fotogramas; súbelo a 3 si el video va lento | `2` |

## Cómo funciona la detección

1. **Captura:** un hilo en segundo plano lee la cámara con `cv2.VideoCapture` y redimensiona cada fotograma a 640 px de ancho.
2. **Detección:**
   - *Rostros:* la imagen se pasa a escala de grises, se ecualiza el histograma y se aplican los clasificadores `haarcascade_frontalface_default.xml` y `haarcascade_profileface.xml`.
   - *Cuerpo:* `cv2.HOGDescriptor` con el SVM preentrenado `getDefaultPeopleDetector()`.
   - En ambos casos se eliminan las cajas duplicadas con supresión de no máximos (`cv2.dnn.NMSBoxes`).
3. **Seguimiento:** se calcula el centroide de cada caja y se asocia con el centroide más cercano del fotograma anterior para conservar el ID.
4. **Conteo:** el número de personas es la mediana de las últimas detecciones (evita parpadeos). Cuando un ID cruza la línea virtual (con un margen de tolerancia) se suma una entrada o una salida.
5. **Resultados:** el fotograma se anota con OpenCV, se codifica en JPEG y se envía al navegador; las estadísticas se consultan por `/api/estado/` y se guardan en PostgreSQL.

## Casos de prueba

```bash
python manage.py test detector
```

Incluye pruebas del rastreador (mantiene IDs, separa personas, elimina desaparecidos), del conteo por línea (entrada y salida), del procesamiento de un fotograma y de las vistas (panel, API y exportación CSV).

Para probar sin cámara se puede usar un video. OpenCV publica uno de peatones en su repositorio (`samples/data/vtest.avi`); descárgalo y en `.env` coloca `VIDEO_SOURCE=ruta/al/vtest.avi` (el video se repite en bucle).

## Rutas principales

| Ruta | Descripción |
|---|---|
| `/` | Panel de monitoreo en vivo |
| `/video/` | Stream MJPEG procesado |
| `/api/estado/` | Estado actual en JSON |
| `/historial/` | Lista de sesiones |
| `/historial/<id>/` | Detalle y gráfica de una sesión |
| `/historial/<id>/csv/` | Exportar registros a CSV |
| `/admin/` | Administración de Django |

## Solución de problemas

- **"No se pudo abrir la cámara":** cierra otras apps que usen la cámara (Zoom, Teams) o prueba `VIDEO_SOURCE=1`.
- **Error de conexión a PostgreSQL:** verifica que el servicio esté iniciado y que los datos de `.env` sean correctos.
- **Video lento:** usa el modo de rostros, baja `HOG_ESCALA` a `1.0` o sube `DETECTAR_CADA_N_FRAMES` a `3`.
- **Detecta pocas personas en modo cuerpo:** sube `HOG_ESCALA` a `2.0` o coloca la cámara más cerca.

## Integrantes

| Nombre | Rol |
|---|---|
| | |
| | |
| | |
| | |
| | |
