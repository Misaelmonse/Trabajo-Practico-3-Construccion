"""
Configuración del proyecto Conteo de Personas en el Laboratorio.

Las variables sensibles (clave secreta, credenciales de PostgreSQL, fuente de video)
se leen del archivo .env (ver .env.example).
"""
import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")


def env_bool(nombre, defecto=False):
    return os.getenv(nombre, str(defecto)).strip().lower() in ("1", "true", "si", "sí", "yes")


SECRET_KEY = os.getenv("DJANGO_SECRET_KEY", "django-insecure-cambiar-esta-clave-en-produccion")
DEBUG = env_bool("DJANGO_DEBUG", True)
ALLOWED_HOSTS = [h.strip() for h in os.getenv("DJANGO_ALLOWED_HOSTS", "127.0.0.1,localhost").split(",") if h.strip()]

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "detector",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "conteo_personas.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "conteo_personas.wsgi.application"

# --- Base de datos: PostgreSQL ---------------------------------------------
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": os.getenv("DB_NAME", "conteo_personas"),
        "USER": os.getenv("DB_USER", "postgres"),
        "PASSWORD": os.getenv("DB_PASSWORD", "postgres"),
        "HOST": os.getenv("DB_HOST", "localhost"),
        "PORT": os.getenv("DB_PORT", "5432"),
    }
}

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

LANGUAGE_CODE = "es-ec"
TIME_ZONE = "America/Guayaquil"
USE_I18N = True
USE_TZ = True

STATIC_URL = "static/"
STATIC_ROOT = BASE_DIR / "staticfiles"

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# --- Parámetros de detección -------------------------------------------------
# Fuente de video: 0 = cámara web integrada, 1 = cámara USB, o ruta/URL de un video.
VIDEO_SOURCE = os.getenv("VIDEO_SOURCE", "0")
# Cada cuántos segundos se guarda un registro del conteo en PostgreSQL.
REGISTRO_INTERVALO_SEGUNDOS = int(os.getenv("REGISTRO_INTERVALO_SEGUNDOS", "5"))
# Aforo por defecto del laboratorio (capacidad del Laboratorio P, Bloque "P").
AFORO_POR_DEFECTO = int(os.getenv("AFORO_POR_DEFECTO", "200"))
# Línea virtual de entrada/salida: posición relativa (0-1) y orientación (horizontal / vertical).
LINEA_POSICION = float(os.getenv("LINEA_POSICION", "0.5"))
LINEA_ORIENTACION = os.getenv("LINEA_ORIENTACION", "horizontal")
# Ampliación de la imagen para el detector HOG (1.0 = rápido, 1.5-2.0 = detecta personas lejanas).
HOG_ESCALA = float(os.getenv("HOG_ESCALA", "1.5"))
# Ejecutar la detección cada N fotogramas (1 = todos; 2-3 = video más fluido en PCs lentas).
DETECTAR_CADA_N_FRAMES = int(os.getenv("DETECTAR_CADA_N_FRAMES", "2"))
